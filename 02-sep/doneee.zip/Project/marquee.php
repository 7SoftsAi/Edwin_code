<?php
// Database connection
$host = 'localhost';
$db = 'user_auth';
$user = 'root'; // Update with your database username
$pass = ''; // Update with your database password

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT text FROM marquee_text WHERE id = 1"; // Assuming there's only one row
$result = $conn->query($sql);

$marquee_text = "Welcome to our Marketing Tools platform! Get started by signing up today."; // Default text
if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $marquee_text = $row['text'];
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Marquee Display</title>
    <style>
        .marquee-container {
            width: 100%;
            overflow: hidden;
            background: #007bff;
            color: #fff;
            padding: 10px 0;
            white-space: nowrap;
            position: relative;
            box-sizing: border-box;
        }

        .marquee-content {
            display: inline-block;
            white-space: nowrap;
            animation: marquee 60s linear infinite;
        }

        @keyframes marquee {
            from {
                transform: translateX(100%);
            }
            to {
                transform: translateX(-100%);
            }
        }
    </style>
</head>
<body>
    <div class="marquee-container">
        <div class="marquee-content">
            <?php echo htmlspecialchars($marquee_text); ?>
        </div>
    </div>
</body>
</html>
