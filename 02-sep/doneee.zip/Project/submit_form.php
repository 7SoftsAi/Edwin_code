<?php
// Define database credentials
$servername = "localhost";
$username = "root"; // Replace with your database username
$password = ""; // Replace with your database password
$dbname = "user_auth"; // Your actual database name

// Create a database connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get form data
$name = $_POST['name'];
$company_name = $_POST['compname'];
$email = $_POST['email'];
$phone = $_POST['phone'];
$plan = $_POST['plan'];

// Handle file uploads
$target_dir = "uploads/"; // Directory where files will be uploaded
if (!is_dir($target_dir)) {
    mkdir($target_dir, 0777, true); // Create the directory if it does not exist
}

// Handle QR code image upload
$qr_code_image = '';
if (isset($_FILES['qr_code_image']) && $_FILES['qr_code_image']['error'] == 0) {
    $qr_code_image = $target_dir . basename($_FILES["qr_code_image"]["name"]);
    move_uploaded_file($_FILES["qr_code_image"]["tmp_name"], $qr_code_image);
}

// Handle payment screenshot upload
$payment_screenshot = '';
if (isset($_FILES['payment_screenshot']) && $_FILES['payment_screenshot']['error'] == 0) {
    $payment_screenshot = $target_dir . basename($_FILES["payment_screenshot"]["name"]);
    move_uploaded_file($_FILES["payment_screenshot"]["tmp_name"], $payment_screenshot);
}

// Check for duplicate email
$check_duplicate = $conn->prepare("SELECT * FROM form_data WHERE email = ?");
$check_duplicate->bind_param("s", $email);
$check_duplicate->execute();
$result = $check_duplicate->get_result();

if ($result->num_rows > 0) {
    // Email already exists, show a popup
    echo "<script>alert('This email is already registered So use another mail id!'); window.history.back();</script>";
} else {
    // Prepare and bind SQL statement to prevent SQL injection
    $stmt = $conn->prepare("INSERT INTO form_data (name, company_name, email, phone_number, plan, qr_code_image, payment_screenshot) VALUES (?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("sssssss", $name, $company_name, $email, $phone, $plan, $qr_code_image, $payment_screenshot);

    // Execute the statement
    if ($stmt->execute()) {
        echo "
        <script>
            // Displaying the alert
            alert('New record created successfully!');
    
            // Writing styled HTML content to the document
            document.write('<div style=\"text-align: center; margin-top: 20px; background-color: #f9f9f9; padding: 20px; border-radius: 8px; box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);\">' +
                            '<p style=\"font-size: 18px; color: #333;\">Please login to access your dashboard</p>' +
                            '<button style=\"background-color: #007bff; color: white; border: none; padding: 10px 20px; border-radius: 5px; cursor: pointer; font-size: 16px; transition: background-color 0.3s;\"' +
                            'onclick=\"window.location.href=\'login.php\'\">Log In</button>' +
                            '</div>');
        </script>";
    } else {
        echo "Error: " . $stmt->error;
    }
    
    
    // Close the statement
    $stmt->close();
}

// Close the connection
$conn->close();
?>
