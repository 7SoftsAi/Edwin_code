<?php
require 'db_connection.php'; // Your database connection file

if (isset($_POST['token']) && isset($_POST['new_password'])) {
    $token = $_POST['token'];
    $new_password = password_hash($_POST['new_password'], PASSWORD_BCRYPT);

    // Update the password in the database and clear the reset token
    $stmt = $mysqli->prepare("UPDATE users SET password = ?, reset_token = NULL, reset_expires = NULL WHERE reset_token = ?");
    $stmt->bind_param("ss", $new_password, $token);
    $stmt->execute();

    if ($stmt->affected_rows > 0) {
        echo "Your password has been reset successfully!";
    } else {
        echo "Failed to reset password!";
    }
} else {
    echo "Invalid request!";
}
?>
