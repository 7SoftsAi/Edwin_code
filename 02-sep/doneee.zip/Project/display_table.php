<?php
require 'db_connection.php'; // Include your database connection file

// Query to select specific columns from the 'users' table
$query = "SELECT id, first_name, last_name, email FROM users";

// Execute the query
$result = $mysqli->query($query);

if ($result) {
    // Start the HTML with custom styles
    echo '<!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>User Details</title>
        <style>
            body {
                font-family: Arial, sans-serif;
                background: linear-gradient(to right, #e0f7fa, #80deea); /* Gradient background */
                margin: 0;
                padding: 20px;
                display: flex;
                justify-content: center;
                align-items: center;
                min-height: 100vh;
            }

            .container {
                max-width: 900px;
                width: 100%;
                background-color: #fff;
                padding: 20px;
                border-radius: 12px;
                box-shadow: 0 4px 16px rgba(0, 0, 0, 0.1);
            }

            h1 {
                text-align: center;
                color: #007bff;
                font-size: 2.2em;
                margin-bottom: 20px;
                border-bottom: 2px solid #007bff;
                padding-bottom: 10px;
            }

            table {
                width: 100%;
                border-collapse: collapse;
                margin-top: 20px;
                overflow-x: auto;
            }

            th, td {
                padding: 12px 15px;
                text-align: left;
                border-bottom: 1px solid #ddd;
                font-size: 14px;
                word-wrap: break-word;
            }

            th {
                background-color: #007bff;
                color: #fff;
                border-radius: 8px 8px 0 0;
            }

            tr:nth-child(even) {
                background-color: #f2f2f2;
            }

            tr:hover {
                background-color: #f1f1f1;
            }

            /* Mobile responsive adjustments */
            @media (max-width: 600px) {
                .container {
                    padding: 15px;
                }

                table, th, td {
                    font-size: 12px;
                    padding: 10px;
                }

                h1 {
                    font-size: 1.8em;
                }

                th, td {
                    display: block;
                    width: 100%;
                    box-sizing: border-box;
                    text-align: right;
                    padding-left: 50%;
                    position: relative;
                }

                th::before, td::before {
                    content: attr(data-label);
                    position: absolute;
                    left: 10px;
                    white-space: nowrap;
                    font-weight: bold;
                    text-align: left;
                }

                th {
                    border-radius: 0;
                }
            }
        </style>
    </head>
    <body>
        <div class="container">
            <h1>User Details</h1>';

    // Start the HTML table
    echo '<table>';
    
    // Table headers with styling
    echo '<tr>';
    echo '<th data-label="ID">ID</th>';
    echo '<th data-label="First Name">First Name</th>';
    echo '<th data-label="Last Name">Last Name</th>';
    echo '<th data-label="Email">Email</th>';
    echo '</tr>';
    
    // Fetch and display each row
    while ($row = $result->fetch_assoc()) {
        echo '<tr>';
        echo '<td data-label="ID">' . htmlspecialchars($row['id']) . '</td>';
        echo '<td data-label="First Name">' . htmlspecialchars($row['first_name']) . '</td>';
        echo '<td data-label="Last Name">' . htmlspecialchars($row['last_name']) . '</td>';
        echo '<td data-label="Email">' . htmlspecialchars($row['email']) . '</td>';
        echo '</tr>';
    }
    
    // End the table and close the container
    echo '</table>
        </div>
    </body>
    </html>';
    
    // Free result set
    $result->free();
} else {
    echo 'Error retrieving data: ' . $mysqli->error;
}

// Close database connection
$mysqli->close();
?>
