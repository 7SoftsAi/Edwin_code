<?php
// Define database credentials
$servername = "localhost";
$username = "root"; // Replace with your database username
$password = ""; // Replace with your database password
$dbname = "user_auth"; // Your actual database name

// Create a database connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch data from the form_data table
$sql = "SELECT * FROM form_data";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Display Form Data</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: linear-gradient(to right, #e0f7fa, #80deea);
            margin: 0;
            padding: 0;
        }

        .container {
            width: 90%;
            max-width: 1200px;
            margin: 20px auto;
            padding: 20px;
            box-sizing: border-box;
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        h2 {
            text-align: center;
            color: #007bff;
            margin-bottom: 20px;
            font-size: 2em;
        }

        .table-wrapper {
            overflow-x: auto; /* Enable horizontal scroll */
            -webkit-overflow-scrolling: touch; /* Smooth scrolling on iOS */
        }

        table {
            width: 100%;
            border-collapse: collapse;
            table-layout: fixed; /* Ensure fixed table layout for better styling */
        }

        th, td {
            padding: 15px;
            border: 1px solid #ddd;
            text-align: left;
            font-size: 14px;
            word-wrap: break-word; /* Prevent overflow */
        }

        th {
            background-color: #007bff;
            color: #fff;
        }

        tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        tr:hover {
            background-color: #f1f1f1;
        }

        img {
            max-width: 100px; /* Limit image width for better display */
            height: auto;
            display: block;
            margin: auto;
        }

        /* Mobile Responsive Design */
        @media (max-width: 768px) {
            table {
                width: 100%;
                border-collapse: collapse;
            }

            thead {
                display: none; /* Hide the table header on smaller screens */
            }

            tr {
                display: block;
                margin-bottom: 15px;
                border-bottom: 2px solid #ddd;
                padding-bottom: 10px;
            }

            td {
                display: block;
                text-align: left;
                padding-left: 50%;
                position: relative;
                white-space: nowrap; /* Prevent text from wrapping */
                overflow: hidden; /* Hide overflowed content */
            }

            td::before {
                content: attr(data-label);
                position: absolute;
                left: 10px;
                font-weight: bold;
                white-space: nowrap;
                text-transform: uppercase;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Payment Details </h2>
        <div class="table-wrapper">
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Company Name</th>
                        <th>Email</th>
                        <th>Phone Number</th>
                        <th>Plan</th>
                        <th>Payment Screenshot</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    if ($result->num_rows > 0) {
                        // Output data of each row
                        while($row = $result->fetch_assoc()) {
                            echo "<tr>";
                            echo "<td data-label='ID'>" . htmlspecialchars($row["id"]) . "</td>";
                            echo "<td data-label='Name'>" . htmlspecialchars($row["name"]) . "</td>";
                            echo "<td data-label='Company Name'>" . htmlspecialchars($row["company_name"]) . "</td>";
                            echo "<td data-label='Email'>" . htmlspecialchars($row["email"]) . "</td>";
                            echo "<td data-label='Phone Number'>" . htmlspecialchars($row["phone_number"]) . "</td>";
                            echo "<td data-label='Plan'>" . htmlspecialchars($row["plan"]) . "</td>";
                            echo "<td data-label='Payment Screenshot'><img src='" . htmlspecialchars($row["payment_screenshot"]) . "' alt='Payment Screenshot'></td>";
                            echo "</tr>";
                        }
                    } else {
                        echo "<tr><td colspan='7'>No records found</td></tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>

    <?php
    // Close the connection
    $conn->close();
    ?>
</body>
</html>
