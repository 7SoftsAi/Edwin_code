<?php
require 'db_connection.php'; // Your database connection file

if (isset($_GET['token'])) {
    $token = $_GET['token'];

    // Check if the token is valid and not expired
    $stmt = $mysqli->prepare("SELECT email, reset_expires FROM users WHERE reset_token = ?");
    $stmt->bind_param("s", $token);
    $stmt->execute();
    $result = $stmt->get_result();
    $current_time = time();

    // Debug output
    echo "Current time: " . date('Y-m-d H:i:s', $current_time) . "<br>";

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $reset_expires = $row['reset_expires'];
        echo "Token expiry time: " . date('Y-m-d H:i:s', $reset_expires) . "<br>";

        if ($current_time <= $reset_expires) {
            // Token is valid, show the password reset form
            $email = htmlspecialchars($row['email']);
            echo '<form action="update_password.php" method="POST">
                    <input type="hidden" name="token" value="' . htmlspecialchars($token) . '">
                    <input type="hidden" name="email" value="' . $email . '">
                    <label for="new_password">New Password:</label>
                    <input type="password" id="new_password" name="new_password" required><br>
                    <button type="submit">Reset Password</button>
                  </form>';
        } else {
            echo "Invalid or expired token!";
        }
    } else {
        echo "Invalid or expired token!";
    }
} else {
    echo "Invalid request!";
}
?>
