<?php
require 'vendor/autoload.php'; // Adjust the path if necessary

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
require 'db_connection.php'; // Your database connection file

if (isset($_POST['email'])) {
    $email = $_POST['email'];

    // Check if the email exists in the database
    $stmt = $mysqli->prepare("SELECT * FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        // Email exists, generate reset token
        $reset_token = bin2hex(random_bytes(16)); // Generate a random reset token
        $reset_expires = time() + (60 * 60); // Set expiry time to 1 hour from now

        // Update the database with the reset token and expiry time
        $stmt = $mysqli->prepare("UPDATE users SET reset_token = ?, reset_expires = ? WHERE email = ?");
        $stmt->bind_param("sis", $reset_token, $reset_expires, $email);
        $stmt->execute();

        // Send reset link to user's email
        $mail = new PHPMailer(true); // Passing `true` enables exceptions

        try {
            // Server settings
            $mail->isSMTP();                                            // Send using SMTP
            $mail->Host       = 'smtp.gmail.com';                       // Set the SMTP server to send through
            $mail->SMTPAuth   = true;                                   // Enable SMTP authentication
            $mail->Username   = 'edwined2805@gmail.com';               // SMTP username
            $mail->Password   = 'uhxrzhlpqgsvgjiw';                   // SMTP password (Use an App Password if 2FA is enabled)
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;           // Enable TLS encryption
            $mail->Port       = 587;                                    // TCP port to connect to

            // Recipients
            $mail->setFrom('edwined2805@gmail.com', 'Your Website');
            $mail->addAddress($email);                                  // Add a recipient

            // Content
            $mail->isHTML(true);                                        // Set email format to HTML
            $mail->Subject = 'Password Reset Request';
            $mail->Body    = 'To reset your password, please click the following link: <a href="http://localhost/Project/reset_password.php?token=' . $reset_token . '">Reset Password</a>';

            $mail->send();
            echo 'A reset link has been sent to your email.';
        } catch (Exception $e) {
            echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
        }
    } else {
        echo "Email not found!";
    }
} else {
    echo "Invalid request!";
}
?>
