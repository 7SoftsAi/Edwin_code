<?php
// Database connection
$conn = new mysqli('localhost', 'root', '', 'user_auth');

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Initialize error message variable
$error_message = '';

// Check if form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $first_name = $_POST['first_name'];
    $last_name = $_POST['last_name'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];

    // Check if passwords match
    if ($password !== $confirm_password) {
        $error_message = "Passwords do not match!";
    } else {
        // Hash the password
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);

        // Check if the email already exists
        $stmt = $conn->prepare("SELECT email FROM users WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $error_message = "This email is already registered.";
        } else {
            // Insert user data into the database
            $stmt = $conn->prepare("INSERT INTO users (first_name, last_name, email, password) VALUES (?, ?, ?, ?)");
            $stmt->bind_param("ssss", $first_name, $last_name, $email, $hashed_password);

            try {
                if ($stmt->execute()) {
                    echo "<div style='font-family: Arial, sans-serif; text-align: center; padding: 20px;'>
                            <h2 style='color: #28a745;'>Registration Successful!</h2>
                            <p style='color: #333; font-size: 16px;'>Admin Panel Login Here!</p>
                            <a href='adminlogin.php' style='display: inline-block; padding: 10px 20px; background-color: #007bff; color: #fff; text-decoration: none; border-radius: 5px; font-size: 16px; transition: background-color 0.3s;'>Login</a>
                          </div>";
                } else {
                    $error_message = 'Error: ' . $stmt->error;
                }
            } catch (mysqli_sql_exception $e) {
                if ($e->getCode() == 1062) { // MySQL error code for duplicate entry
                    $error_message = 'This email is already registered.';
                } else {
                    $error_message = 'Database error: ' . $e->getMessage();
                }
            }
        }
        $stmt->close();
    }

    if ($error_message) {
        echo "<script>alert('$error_message'); window.location.href='register.php';</script>";
    }
}

$conn->close();
?>
