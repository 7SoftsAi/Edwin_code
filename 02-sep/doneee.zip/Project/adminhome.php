<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: linear-gradient(to right, #e0f7fa, #80deea); /* Gradient background */
            margin: 0;
            padding: 0;
            color: #333;
            display: flex;
            align-items: center;
            justify-content: center;
            height: 100vh;
        }

        .container {
            max-width: 800px;
            margin: 20px;
            padding: 30px;
            background-color: #fff;
            border-radius: 12px;
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2);
            text-align: center;
            border: 2px solid #0072ff; /* Attractive border */
        }

        h1 {
            color: #0072ff;
            font-size: 2.5em;
            margin-bottom: 20px;
            font-weight: bold;
        }

        .button-container {
            display: flex;
            justify-content: center;
            flex-wrap: wrap;
            margin-bottom: 20px;
        }

        .button-container .button {
            margin: 10px;
            text-align: center;
        }

        .button {
            display: inline-block;
            padding: 12px 25px;
            background-color: #0072ff;
            color: #fff;
            text-decoration: none;
            border-radius: 8px;
            font-size: 18px;
            transition: background-color 0.3s, transform 0.3s;
            border: none;
            cursor: pointer;
        }

        .button:hover {
            background-color: #0056b3;
            transform: scale(1.05);
        }

        .logout {
            background-color: #ff4d4d;
        }

        .logout:hover {
            background-color: #e60000;
        }

        .logout-container {
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Welcome to Admin Dashboard</h1>

        <div class="button-container">
            <a href="display_table.php" class="button">View User Details</a>
            <a href="display_data.php" class="button">View Payment Details</a>
            <a href="update_marquee.php" class="button">Update Marquee Text</a>
        </div>

        <div class="logout-container">
            <a href="adminlogin.php" class="button logout">Logout</a>
        </div>
    </div>
</body>
</html>
