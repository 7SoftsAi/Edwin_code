<?php
// Start the session
session_start();

// Check if the user is logged in by verifying the session variable
if (!isset($_SESSION['user_id'])) {
    // If the user is not logged in, redirect them to the login page
    header("Location: login.php");
    exit();
}
?>

<!-- <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
</head>
<body>
<h1 style="text-align: center; color: #007bff;">Welcome to your Dashboard</h1>
   <p><a href="your_url_page.php">Go to Another Page</a></p>
  <p><a href="logout.php">Logout</a></p>
</body>
</html> -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="styles.css">
    <title>My Services</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">

    <style>
        /* Reset some basic styles */
body, html {
    margin: 0;
    padding: 0;
    font-family: Arial, sans-serif;
}


/* Container for the chat section starts here ===================*/
.chat-section-container {
    position: relative;
    width: 100%;
    overflow: hidden;
}

.slider {
    display: flex;
    transition: transform 0.5s ease-in-out;
}

.chat-section {
    min-width: 100%;
    box-sizing: border-box;
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 20px;
    background: linear-gradient(135deg, #f3f4f6, #d1e5f0);
    border-radius: 10px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
}

.prev, .next {
    position: absolute;
    top: 50%;
    transform: translateY(-50%);
    background-color: rgba(0, 0, 0, 0.5);
    color: white;
    border: none;
    padding: 10px;
    cursor: pointer;
    border-radius: 50%;
    z-index: 2;
}

.prev {
    left: 10px;
}

.next {
    right: 10px;
}

.prev:hover, .next:hover {
    background-color: rgba(0, 0, 0, 0.8);
}

.chat-content {
    flex: 1;
    padding: 20px;
    text-align: center;
}

.chat-content h1 {
    color: #2c3e50;
    font-size: 28px;
    margin-bottom: 15px;
}

.chat-content p {
    color: #34495e;
    font-size: 16px;
    margin-bottom: 20px;
}

.chat-content button {
    background-color: #007BFF;
    color: #ffffff;
    border: none;
    padding: 10px 20px;
    border-radius: 5px;
    cursor: pointer;
    font-size: 16px;
}

.chat-content button:hover {
    background-color: #0056b3;
}

.chat-image {
    flex: 1;
    text-align: center;
    margin-top: 20px;
}

.chat-image img {
    max-width: 50%;
    height: auto;
    border-radius: 10px;
}


/* Responsive styling */
@media (max-width: 1024px) {
    .chat-section {
        max-width: 100%;
        padding: 15px;
    }

    .chat-content h1 {
        font-size: 24px; /* Adjust font size */
    }

    .chat-content p {
        font-size: 14px; /* Adjust font size */
    }

    .chat-content button {
        padding: 8px 16px; /* Adjust button padding */
        font-size: 14px; /* Adjust font size */
    }
}

@media (max-width: 768px) {
    .chat-section {
        flex-direction: row; /* Stack content and image vertically */
        align-items: center;
        padding: 15px;
    }

    .chat-content {
        text-align: center; /* Center text */
    }

    .chat-image {
        margin-top: 15px; /* Adjust margin for spacing */
    }

    .chat-content h1 {
        font-size: 22px; /* Adjust font size */
    }

    .chat-content p {
        font-size: 14px; /* Adjust font size */
    }

    .chat-content button {
        padding: 8px 16px; /* Adjust button padding */
        font-size: 14px; /* Adjust font size */
    }

    .chat-image img {
        max-width: 70%; /* Reduce image size */
    }
}

@media (max-width: 480px) {
    .chat-section {
        padding: 10px;
        margin-top: 50px;
    }

    .chat-content h1 {
        font-size: 20px; /* Further reduce font size */
    }

    .chat-content p {
        font-size: 13px; /* Further reduce font size */
    }

    .chat-content button {
        padding: 6px 12px; /* Further adjust button padding */
        font-size: 13px; /* Further reduce font size */
    }

    .chat-image img {
        max-width: 100%; /* Make the image take full width */
        border-radius: 8px;
    }
}



/* Container styling */
.container {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 20px 30px;
    background-color: #1f3c88;
    font-weight: bold;
    color: #fff;
    flex-wrap: nowrap; /* Prevent wrapping */
}

/* Brand name styling */
.brand-name {
    font-size: 1.5rem;
    font-weight: bold;
    text-decoration: none;
    color: #fff;
}

/* Nav links styling */
.nav-links {
    display: flex;
    gap: 35px;
    flex-wrap: nowrap; /* Keep nav links in a single line */
}

.nav-link {
    color: #fff;
    text-decoration: none;
    font-weight: bold;
    font-size: 1.4rem;
    transition: color 0.3s ease;
}

.nav-link:hover {
    color: #f39c12;
}

/* Auth buttons styling */
.auth-buttons {
    display: flex;
    gap: 10px;
    flex-wrap: nowrap; /* Keep buttons in a single line */
}

.auth-btn {
    background-color: #646163;
    border: none;
    padding: 10px 15px;
    border-radius: 5px;
    color: #fff;
    cursor: pointer;
    font-size: 1.3rem;
    font-weight: bold;
    transition: background-color 0.3s ease;
}

.auth-btn:hover {
    background-color: #332822;
}

/* Sign-Up Button */
.sign-up-btn {
    background-color: black;
    color: white;
    padding: 1rem 1.5rem;
    border: none;
    cursor: pointer;
    font-size: 1rem;
    font-weight: bold;
    border-radius: 5px;
}

.sign-up-btn:hover {
    background-color: rgba(113, 135, 161, 0.8);
    transform: translateY(-2px);
}

/* Responsive styling */
@media (max-width: 768px) {
    .container {
        padding: 15px 20px; /* Adjust padding */
    }

    .brand-name {
        font-size: 1.3rem; /* Slightly reduce brand name size */
    }

    .nav-links {
        gap: 20px; /* Reduce gap between links */
    }

    .nav-link {
        font-size: 1.2rem; /* Reduce font size */
    }

    .auth-buttons {
        gap: 5px; /* Reduce gap between buttons */
    }

    .auth-btn {
        padding: 8px 12px; /* Reduce padding */
        font-size: 1.1rem; /* Reduce font size */
    }

    .sign-up-btn {
        padding: 0.8rem 1.2rem; /* Reduce padding */
        font-size: 0.9rem; /* Reduce font size */
    }
}

@media (max-width: 480px) {
    .container {
        flex-direction: column; /* Stack elements vertically on very small screens */
        align-items: center;
        padding: 10px 15px; /* Reduce padding further */
    }

    .brand-name {
        margin-bottom: 10px; /* Add space below brand name */
        font-size: 1.2rem;
    }

    .nav-links {
        flex-direction: row;
        flex-wrap: wrap; /* Allow wrapping */
        justify-content: center;
        gap: 15px; /* Reduce gap between links */
        margin-bottom: 10px; /* Add space below nav links */
    }

    .auth-buttons {
        flex-direction: row;
        flex-wrap: wrap; /* Allow buttons to wrap */
        justify-content: center;
        gap: 5px; /* Reduce gap between buttons */
    }

    .auth-btn, .sign-up-btn {
        font-size: 1rem; /* Consistent font size */
        padding: 8px 12px; /* Consistent padding */
    }
}


#features {
    padding: 20px;
    background: linear-gradient(to right,  #8e44ad, white); /* Gradient background */
}

.features-container {
    /* background-color: #fff; */
    padding: 20px;
    border-radius: 10px;
    /* box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.1); */
    max-width: 1200px;
    margin: 0 auto;
}

.features-container h1 {
    margin-bottom: 20px;
    font-size: 38px;
    color: #333;
    text-align: center;
    transition: transform 0.3s ease, box-shadow 0.3s ease;
}

.features-wrapper {
    display: flex;
    flex-wrap: wrap;
    gap: 20px;
    
    transition: transform 0.3s ease, box-shadow 0.3s ease;
}

.feature-box {
    background-color: #f9f9f9;
    padding: 20px;
    border-radius: 10px;
    border: 2px solid #e0aaff; /* Border color */
    box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.1);
    width: calc(33.333% - 20px);
    box-sizing: border-box;
    text-align: center;
    min-width: 300px;
    transition: transform 0.3s ease, box-shadow 0.3s ease; 
    transition: transform 0.3s ease, box-shadow 0.3s ease;
    
}

.feature-box img {
    width: 100px;
    height: 100px;
    margin-bottom: 10px;
}

.feature-box h3 {
    margin-top: 0;
    color: #333;
    font-size: 24px;
    transform: translateY(-10px); /* Lift the box up slightly */
}

.feature-box p {
    color: #666;
    font-size: 16px;
    line-height: 1.5;
}

/* Basic styling for the <a> tags wrapping the <h3> elements */
.features-wrapper .feature-box a {
    text-decoration: none;          /* Removes underline from links */
    color: #333;                    /* Sets the text color */
    transition: color 0.3s ease;    /* Smooth transition for color change on hover */
}

.features-wrapper .feature-box a:hover {
    color: #007BFF;                 /* Changes color on hover */
    text-decoration: none;     /* Adds underline on hover */
}

.features-wrapper .feature-box a h3 {
    font-size: 1.4em;               /* Adjusts font size */
    margin: 0;                      /* Removes default margin */
    padding: 0; 
    margin-bottom: 10px;        
    transform: translateY(-10px); /* Lift the box up slightly */            /* Removes default padding */
}

.download-btn {
    display: inline-block;
    margin-top: 15px;
    padding: 10px 20px;
    background-color: #007BFF;
    color: #fff;
    font-size: 18px;
    font-weight: bold;
    text-align: center;
    text-decoration: none;
    border-radius: 5px;
    box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.1);
    transition: background-color 0.3s ease, transform 0.3s ease;
}

.download-btn:hover {
    background-color: #0056b3;
    transform: translateY(-2px);
    color: white;
    
}

.download-btn:active {
    background-color: #004494;
    transform: translateY(0);
}



/* Main container box */
/* Container styling */
.container5 {
    /* margin: 50px auto; */
    width: 100%;
    height: 400px;
    background: rgb(89,89,89);
    background: linear-gradient(to right,  #8e44ad, white); /* Gradient background */
 /* Gradient background */
    display: flex;
    justify-content: center;
    align-items: center;
    flex-direction: column; /* Ensures the h2 tag and boxes are centered */
}

/* Styling for h2 tag */
.container5 h2 {
    font-size: 32px;
    color: #2c3e50;
    text-align: center;
    margin-bottom: 30px;
    /* background: linear-gradient(135deg, #ec8eec, #ddd9dc);  */
}

/* Main container box */
.main-box {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    grid-gap: 20px;
    padding: 20px;
    /* background: linear-gradient(135deg, #ec8eec, #ddd9dc);  */
}
.container5 {
    background: linear-gradient(to right,  #8e44ad, white); /* Gradient background */ 
    padding: 20px;
    /* border-radius: 8px; */
    text-align: center; /* Center align text */
}

.container5 h2 {
    margin-bottom: 20px;
    color: black; /* White color for the heading */
}

.main-box {
    display: flex;
    justify-content: center;
    align-items: center;
    gap: 20px;
    flex-wrap: wrap; /* Make the boxes wrap on smaller screens */
}

.small-box {
    width: 280px;
    height: 180px;
    background: rgb(89,89,89);
    background: linear-gradient(90deg, rgba(89,89,89,0.6615021008403361) 0%, rgba(101,174,236,1) 0%, rgb(205, 209, 146) 100%);
    justify-content: center;
    align-items: center;
    display: flex;
    border-radius: 8px;
    color: black; /* White text color */
    font-size: 19px;
    font-weight: bold;
    padding: 10px;
}
.small-box:hover {
    transform: translateY(-10px); /* Lift the box up slightly */
    box-shadow: 0 10px 20px rgba(0, 0, 0, 0.2); /* Add shadow */
    background: linear-gradient(90deg, rgba(101,174,236,1) 0%, rgb(205, 209, 146) 50%, rgba(89,89,89,0.66) 100%);
}

.box-title {
    display: block;
    text-align: center;
}

/* Responsive styling */
@media (max-width: 768px) {
    .main-box {
        flex-direction: column;
        gap: 10px;
    }

    .small-box {
        width: 80px;
        height: 80px;
    }
}

/* database and email section ends  here  */

/* Main Container */
.container1 {
    max-width: 100%;
    margin: 0 auto;
    display: flex;
    padding-right: 20px;
    justify-content: space-between;
    align-items: center;
    text-align: center;
    min-height: 80vh;
    background: linear-gradient(to right,  #8e44ad,white);
}

.content-left {
    max-width: 40%;
    text-align: left;
    padding: 20px;
    color: white;
}

.content-left h1 {
    font-size: 2.5rem;
    margin-bottom: 10px;
}

.content-left p {
    font-size: 1.2rem;
    line-height: 1.5;
}

/* Button Styling */
.start-now-btn {
    background-color: #28a745;
    color: #fff;
    padding: 15px 30px;
    font-size: 1.2rem;
    border: none;
    border-radius: 30px;
    cursor: pointer;
    transition: background-color 0.3s ease, transform 0.3s ease;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
}

.start-now-btn:hover {
    background-color: #218838;
    transform: translateY(-3px);
}

.start-now-btn:active {
    background-color: #1e7e34;
    transform: translateY(0);
}

.image-grid {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 20px;
    justify-items: center;
    align-items: center;
}

/* Image Item */
.image-item {
    background-color: #7b5ed6;
    border-radius: 15px;
    padding: 20px;
    text-align: center;
    width: 180px;
    transition: transform 0.3s ease, box-shadow 0.3s ease;
}

.image-item img {
    width: 80px;
    height: 80px;
    object-fit: contain;
    margin-bottom: 10px;
}

.image-item h3 {
    font-size: 1rem;
    color: white;
}

/* Hover Effects */
.image-item:hover {
    transform: translateY(-5px);
    box-shadow: 0px 8px 15px rgba(0, 0, 0, 0.2);
}

.image-item a {
    text-decoration: none;
}

/* Media Queries for Responsiveness */

/* Large devices (desktops, 992px and up) */
@media (min-width: 992px) {
    .image-grid {
        grid-template-columns: repeat(4, 1fr);
    }
}

/* Medium devices (tablets, 768px and up) */
@media (max-width: 991px) {
    .image-grid {
        grid-template-columns: repeat(3, 1fr);
    }

    .brand-name {
        font-size: 1.5rem;
    }

    .sign-up-btn {
        padding: 0.75rem 1rem;
    }

    .content-left h1 {
        font-size: 2.2rem;
    }

    .content-left p {
        font-size: 1.1rem;
    }
}

/* Small devices (landscape phones, 576px and up) */
@media (max-width: 767px) {
    .container1 {
        flex-direction: column;
        padding-right: 0;
        padding-left: 20px;
    }

    .image-grid {
        grid-template-columns: repeat(2, 1fr);
        gap: 15px;
    }

    .content-left {
        max-width: 100%;
        text-align: center;
    }

    .brand-name {
        font-size: 1.25rem;
    }

    .sign-up-btn {
        padding: 0.5rem 0.75rem;
    }

    .content-left h1 {
        font-size: 2rem;
    }

    .content-left p {
        font-size: 1rem;
    }
}

/* Extra small devices (portrait phones, less than 576px) */
@media (max-width: 575px) {
    .container1 {
        flex-direction: column;
        padding: 0 15px;
    }

    .image-grid {
        grid-template-columns: 1fr;
        gap: 10px;
    }

    .brand-name {
        font-size: 1rem;
    }

    .sign-up-btn {
        padding: 0.5rem;
        font-size: 0.875rem;
    }

    .content-left h1 {
        font-size: 1.75rem;
    }

    .content-left p {
        font-size: 0.9rem;
    }
}


/* Basic reset */
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

/* Features section styling */
.features-section {
    padding: 50px 20px;
    background: linear-gradient(to right,  #8e44ad, white); /* Gradient background */
}

/* Section title styling */
.section-title {
    font-size: 2.5rem;
    color: white;
    margin-bottom: 40px;
    font-weight: bold;
    text-align: center; /* Center align the h2 */
}

/* Grid container styling */
.grid-container {
    display: grid;
    grid-template-columns: 1fr;
    gap: 20px;
    padding: 20px;
    max-width: 1200px;
    margin: 0 auto;
}

@media (min-width: 768px) {
    .grid-container {
        grid-template-columns: 1fr 1fr;
    }
}

@media (min-width: 1024px) {
    .grid-container {
        grid-template-columns: 1fr 1fr 1fr;
    }
}

/* Card styling */
.card {
    border-radius: 10px;
    padding: 20px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    text-align: center;
    transition: transform 0.3s ease, box-shadow 0.3s ease;
    color: white; /* Ensure the text color is white */
    text-decoration: none; /* Remove underline */
    display: block; /* Make the whole card clickable */
}

/* Unique card background colors */
.card-1 {
    background-color: #3498db; /* Blue */
}

.card-2 {
    background-color: #e67e22; /* Orange */
}

.card-3 {
    background-color: #8e44ad; /* Purple */
}

.card:hover {
    transform: translateY(-5px);
    box-shadow: 0 8px 15px rgba(0, 0, 0, 0.2);
}

/* Card image styling */
.card-image {
    width: 64px;
    height: 64px;
    margin-bottom: 20px;
}

/* Card title styling */
.card-title {
    font-size: 1.5rem;
    margin-bottom: 15px;
    color: white;
}

/* Card text styling */
.card-text {
    font-size: 1rem;
    color: black;
    line-height: 1.5;
}

/* Responsive adjustments for text size */
@media (min-width: 768px) {
    .card-title {
        font-size: 1.75rem;
    }

    .card-text {
        font-size: 1.1rem;
    }
}

@media (min-width: 1024px) {
    .card-title {
        font-size: 2rem;
    }

    .card-text {
        font-size: 1.2rem;
    }
}


/* testimonial section starts here ================================ */

.testimonials-section {
    text-align: center;
    padding: 50px 10px;
    background: linear-gradient(135deg, #8e44ad, white);

}

.testimonials-section h2 {
    font-size: 1.2rem;
    text-transform: uppercase;
    color: #888;
    margin-bottom: 10px;
}

.testimonials-section h1 {
    font-size: 2.5rem;
    font-weight: bold;
    color: #333;
    margin-bottom: 20px;
}

.testimonials-section .view-testimonials {
    color: #007bff;
    text-decoration: none;
    font-weight: bold;
    font-size: 1.2rem;
    display: inline-block;
    margin-bottom: 40px;
}

.testimonials-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
    gap: 20px;
    max-width: 1200px;
    margin: 0 auto;
}

.testimonial-card {
    background: #fff;
    border-radius: 10px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    padding: 20px;
    text-align: left;
    position: relative;
}

.testimonial-icon {
    width: 40px;
    height: 40px;
    position: absolute;
    top: 20px;
    left: 20px;
    border-radius: 50%;
}

.testimonial-card h3 {
    font-size: 1.2rem;
    color: #333;
    margin-left: 70px; /* Adjust left margin to make room for the image */
    margin-bottom: 5px;
}

.testimonial-card p {
    font-size: 0.9rem;
    color: #777;
    margin-left: 70px; /* Adjust left margin to make room for the image */
    margin-bottom: 15px;
}

.testimonial-card blockquote {
    font-size: 0.9rem;
    color: #555;
    margin: 0;
    padding-left: 15px;
    /* border-left: 4px solid #007bff; */
}

.testimonial-card blockquote p {
    margin: 0;
}


/* Container for the chat section starts here ===================*/
.chat-section-container {
    display: flex;
    justify-content: center;
    align-items: center;
    height: 70vh;
    background: linear-gradient(135deg,    #8e44ad, white); /* Gradient background */
    padding: 20px; /* Add padding for small screens */
}

/* Chat section styling */
.chat-section {
    display: flex;
    align-items: center;
    background: linear-gradient(135deg, #f3f4f6, #d1e5f0); /* Background color of chat section */
    padding: 20px;
    border-radius: 10px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    max-width: 70%;
    width: 100%;
    flex-wrap: wrap; /* Allow wrapping for responsive layout */
}

/* Styling for chat content */
.chat-content {
    flex: 1;
    padding: 20px;
    text-align: center; /* Center text for smaller screens */
}

.chat-content h1 {
    color: #2c3e50; /* Darker color for heading */
    font-size: 28px; /* Adjust font size for readability */
    margin-bottom: 15px;
}

.chat-content p {
    color: #34495e; /* Slightly lighter color for paragraph */
    font-size: 16px; /* Adjust font size for readability */
    margin-bottom: 20px;
}

.chat-content button {
    background-color: #007BFF; /* Button color */
    color: #ffffff;
    border: none;
    padding: 10px 20px;
    border-radius: 5px;
    cursor: pointer;
    font-size: 16px;
}

.chat-content button:hover {
    background-color: #0056b3; /* Button hover color */
}

/* Styling for chat image */
.chat-image {
    flex: 1;
    text-align: center;
    margin-top: 20px; /* Add margin for spacing on small screens */
}

.chat-image img {
    /* max-width: 80%; */
    height: auto;
    border-radius: 10px;
}

/* Responsive styling */
@media (max-width: 1024px) {
    .chat-section {
        max-width: 100%;
        padding: 15px;
    }

    .chat-content h1 {
        font-size: 24px; /* Adjust font size */
    }

    .chat-content p {
        font-size: 14px; /* Adjust font size */
    }

    .chat-content button {
        padding: 8px 16px; /* Adjust button padding */
        font-size: 14px; /* Adjust font size */
    }
}

@media (max-width: 768px) {
    .chat-section {
        flex-direction: row; /* Stack content and image vertically */
        align-items: center;
        padding: 15px;
    }

    .chat-content {
        text-align: center; /* Center text */
    }

    .chat-image {
        margin-top: 15px; /* Adjust margin for spacing */
    }

    .chat-content h1 {
        font-size: 22px; /* Adjust font size */
    }

    .chat-content p {
        font-size: 14px; /* Adjust font size */
    }

    .chat-content button {
        padding: 8px 16px; /* Adjust button padding */
        font-size: 14px; /* Adjust font size */
    }

    .chat-image img {
        max-width: 70%; /* Reduce image size */
    }
}

@media (max-width: 480px) {
    .chat-section {
        padding: 10px;
        margin-top: 50px;
    }

    .chat-content h1 {
        font-size: 20px; /* Further reduce font size */
    }

    .chat-content p {
        font-size: 13px; /* Further reduce font size */
    }

    .chat-content button {
        padding: 6px 12px; /* Further adjust button padding */
        font-size: 13px; /* Further reduce font size */
    }

    .chat-image img {
        max-width: 100%; /* Make the image take full width */
        border-radius: 8px;
    }
}



/* Meera code pricing  */
/* ==================================================================  */
/* Global Styles */
/* body {
    background: #f4f4f4; 
    font-family: Arial, sans-serif;
    margin: 0;
    padding: 0;
} */

/* Basic styling for the header section */
.pricing-header {
    display: flex;
    justify-content: center;
    align-items: center;
    text-align: center;
    padding: 20px;
    font-size: 1.5rem;
    background-color: #007BFF; /* Background color */
    border-radius: 10px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1); /* Subtle shadow for depth */
    margin: 20px auto; /* Center the div with auto margins */
    max-width: 80%; /* Restrict the maximum width */
}

/* Styling for the heading */
.pricing-header h1 {
    color: #ffffff; /* White text color */
    font-size: 36px; /* Font size for larger screens */
    margin: 0; /* Remove default margin */
    padding: 10px;
}

/* Responsive styling */
@media (max-width: 1024px) {
    .pricing-header {
        padding: 15px;
        max-width: 90%;
    }

    .pricing-header h1 {
        font-size: 30px; /* Reduce font size for medium screens */
    }
}

@media (max-width: 768px) {
    .pricing-header {
        padding: 10px;
        max-width: 50%;
        margin-top: 80px;
    }

    .pricing-header h1 {
        font-size: 26px; /* Further reduce font size */
    }
}

@media (max-width: 480px) {
    .pricing-header {
        padding: 8px;
        max-width: 100%;
        margin-top: 100px;
    }

    .pricing-header h1 {
        font-size: 22px; /* Smaller font size for mobile screens */
    }
}


/* Pricing Page Heading Styles */
.pricing-header {
    background: linear-gradient(45deg,  #8e44ad, #10b7bd); 
    /* background-color: rgb(241, 138, 98); */
    padding: 20px;
    text-align: center;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1); /* Light shadow for depth */
    margin-bottom: 50px; /* Space below the header */
}

.pricing-header h1 {
    font-size: 36px;
    color: #ffffff; /* White text color for contrast */
    text-transform: uppercase;
    letter-spacing: 2px; /* Spacing between letters for a modern look */
    margin: 0;
    font-weight: bold;
}

/* Pricing Section Styles */
.pricing {
    width: 100%;
    max-width: 1000px;
    background: transparent; /* Remove background color */
    color: #333333; /* Dark text color for readability */
    font-size: 14px;
    line-height: 150%;
    text-align: center;
    margin: 0 auto;
    list-style-type: none;
    display: flex;
    flex-wrap: wrap;
    gap: 20px;
    padding: 0 20px; /* Add padding for responsiveness */
}

.pricing > li {
    background: #ffffff; /* White background for pricing boxes */
    border: 1px solid #ff6f61; /* Coral border for contrast */
    flex: 1 1 calc(33.333% - 20px); /* Adjust for 3 items per row on larger screens */
    transition: all 0.2s ease;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    display: flex;
    flex-direction: column;
    margin-bottom: 20px;
    padding: 20px;
}

.pricing h3 {
    text-transform: uppercase;
    padding: 15px 0;
    font-size: 16px;
    font-weight: bold;
    color: #ff6f61; /* Coral text color */
}

.pricing .price_body {
    width: 125px;
    height: 125px;
    margin: 0 auto 15px auto;
    border: 2px solid #ff6f61; /* Coral border for price body */
    border-radius: 100%;
    display: table;
}

.pricing .price {
    font-size: 30px;
    font-weight: bold;
    text-transform: uppercase;
    vertical-align: middle;
    display: table-cell;
    color: #ff6f61; /* Coral text color */
}

.pricing .price .price_figure {
    display: block;
}

.pricing .price .price_term {
    font-size: 11px;
    font-weight: normal;
}

.pricing .features {
    flex: 1;
    display: flex;
    flex-direction: column;
    justify-content: center;
}

.pricing .features li {
    list-style-type: none;
    padding: 5px 0;
    color: #333333; /* Dark text color for readability */
}

.pricing .footer {
    padding: 10px;
    background: #ff6f61; /* Coral background for footer */
    margin-top: auto;
}

.pricing .footer .action_button {
    color: #ffffff; /* White text color for buttons */
    font-size: 11px;
    display: inline-block;
    text-decoration: none;
    font-weight: bold;
    background: #1f3c88 ; /* Orange background for buttons */
    padding: 4px 20px;
    border-radius: 15px;
    transition: background 0.2s ease;
}

.pricing li.active .footer .action_button {
    background: #e07b39; /* Darker orange for active buttons */
}

.pricing .footer .action_button:hover {
    background: #e07b39; /* Darker orange on hover */
}

/* Responsive Styles */
@media (max-width: 1200px) {
    .pricing > li {
        flex: 1 1 calc(50% - 20px); /* Adjust for 2 items per row on medium screens */
    }
}

@media (max-width: 768px) {
    .pricing > li {
        flex: 1 1 100%; /* Adjust for 1 item per row on small screens */
    }

    .pricing-header h1 {
        font-size: 28px; /* Adjust heading size for smaller screens */
    }
}



/* contact page meera =======================================  */
/* body {
    font-family: 'Helvetica Neue', Arial, sans-serif;
    margin: 0;
    padding: 0;
    background-color: #e0f7fa;
    color: #333;
} */

.contact-container {
    max-width: 1200px;
    margin: 50px auto;
    padding: 20px;
    background-color: #ffffff;
    border-radius: 10px;
    box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
}

.contact-header {
    text-align: center;
    margin-bottom: 40px;
}

.contact-header h1 {
    font-size: 3em;
    color: #82716e;
    margin-bottom: 10px;
}

.contact-header p {
    font-size: 1.2em;
    color: #666666;
}

.contact-content {
    display: flex;
    justify-content: space-between;
    gap: 20px;
    flex-wrap: wrap;  /* Allows wrapping for smaller screens */
}

.contact-info, .contact-form {
    flex: 1;
    padding: 20px;
    background-color: #f7f9fc;
    border-radius: 10px;
    margin-bottom: 20px;
}

.contact-info {
    background-color: #f7f9fc;
}

.contact-info h2, .contact-form h2 {
    font-size: 2em;
    color: #82716e;
    margin-bottom: 20px;
}

.contact-info ul {
    list-style: none;
    padding: 0;
}

.contact-info li {
    font-size: 1.2em;
    margin-bottom: 10px;
    color: #555555;
}

.contact-form {
    background-color: #ffffff;
    box-shadow: 0 3px 10px rgba(0, 0, 0, 0.1);
}

.contact-form label {
    display: block;
    font-size: 1.2em;
    color: #555555;
    margin-bottom: 10px;
}

.contact-form input,
.contact-form textarea {
    width: 100%;
    padding: 15px;
    margin-bottom: 20px;
    border: 1px solid #ccc;
    border-radius: 5px;
    font-size: 1em;
    color: #333333;
}

.contact-form button {
    display: inline-block;
    background-color: #82716e;
    color: #ffffff;
    padding: 15px 30px;
    border: none;
    border-radius: 5px;
    font-size: 1.2em;
    cursor: pointer;
    transition: background-color 0.3s ease;
}

.contact-form button:hover {
    background-color: #6e5f4f;
}

/* Responsive Design */
@media (max-width: 768px) {
    .contact-header h1 {
        font-size: 2.5em;
    }

    .contact-header p {
        font-size: 1em;
    }

    .contact-info h2,
    .contact-form h2 {
        font-size: 1.8em;
    }

    .contact-info, .contact-form {
        flex: 1 1 100%;
        margin-bottom: 20px;
    }

    .contact-info ul li {
        font-size: 1em;
    }

    .contact-form button {
        width: 100%;
        font-size: 1em;
    }
}

@media (max-width: 480px) {
    .contact-header h1 {
        font-size: 2em;
    }

    .contact-header p {
        font-size: 0.9em;
    }

    .contact-info h2,
    .contact-form h2 {
        font-size: 1.6em;
    }

    .contact-info ul li {
        font-size: 0.9em;
    }
}


/* faq css starts here meera =================================== */
body {
    font-family: 'Arial', sans-serif;
    margin: 0;
    padding: 0;
    background: linear-gradient(135deg, #8e44ad, white);
    color: #333;
}

.faq-section {
    max-width: 1000px;
    margin: 30px auto;
    padding: 20px;
    background-color: #ffffff;
    border-radius: 8px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
}

h1 {
    text-align: center;
    color: #333333;
    font-size: 2.5em;
    margin-bottom: 20px;
    font-weight: 600;
}

.faq-item {
    padding: 15px 0;
    border-bottom: 1px solid #dcdcdc;
}

.faq-item:last-child {
    border-bottom: none;
}

.question {
    display: flex;
    justify-content: space-between;
    align-items: center;
    cursor: pointer;
    padding: 15px;
    background: #ffffff;
    border-radius: 8px;
    transition: background-color 0.3s ease;
}

.question:hover {
    background: #f0f0f0;
}

h2 {
    margin: 0;
    font-size: 1.5em;
    color: #333333;
}

.toggle-icon {
    font-size: 1.8em;
    color: #333333;
    transition: transform 0.3s ease;
}

.answer {
    max-height: 0;
    overflow: hidden;
    transition: max-height 0.3s ease-out;
    padding: 0 20px;
    background-color: #ffffff;
    border-radius: 8px;
}

.answer.active {
    max-height: 200px; /* Adjust this as needed */
    padding: 15px 20px;
}

.answer p {
    margin: 0;
}

@media (max-width: 768px) {
    .faq-section {
        padding: 15px;
    }

    h1 {
        font-size: 2em;
    }
}

.marquee-line {
    font-size: 20px;
    color:  #1f3c88;
    margin-top: 10px;
}






/* faq ends here ===================== */
    </style>
</head>

<!-- <script>
    // Check if the user is logged in
    if (!localStorage.getItem('isLoggedIn')) {
        window.location.href = 'login.html';
    } else {
        // Replace the history state to prevent going back to login page
        history.replaceState(null, null, window.location.href);
    }
</script> -->
</script>
<body>
    <header class="header">
        <div class="container">
            <a href="#" class="brand-name">Marketing Tools</a>
            <!-- <nav class="nav-links">
                <a href="#features" class="nav-link">Features</a>
                <a href="#demo" class="nav-link">Demo</a>
                <a href="#pricing" class="nav-link">Pricing</a>
                <a href="#contact" class="nav-link">Contact</a>
            </nav> -->
            <div class="auth-buttons">
                <!-- <button class="auth-btn" onclick="logout()">Log Out</button> -->
                <a href="login.php"><button class="auth-btn">Log Out</button></a>
            </div>
        </div>
    </header>

    <!-- <div class="marquee-container">
        <marquee behavior="scroll" direction="left" class="marquee-line">
            Welcome to our Marketing Tools platform! Get started by signing up today.
        </marquee>
    </div> -->


    <?php
// Database connection
$host = 'localhost';
$db = 'user_auth';
$user = 'root'; // Update with your database username
$pass = ''; // Update with your database password

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT text FROM marquee_text WHERE id = 1"; // Assuming there's only one row
$result = $conn->query($sql);

$marquee_text = "Welcome to our Marketing Tools platform! Get started by signing up today."; // Default text
if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $marquee_text = $row['text'];
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Marquee Display</title>
    <style>
        .marquee-container {
            width: 100%;
            overflow: hidden;
            background: #A020F0;
            color: #fff;
            padding: 10px 0;
            white-space: nowrap;
            position: relative;
            box-sizing: border-box;
        }

        .marquee-content {
            display: inline-block;
            white-space: nowrap;
            animation: marquee 60s linear infinite;
        }

        @keyframes marquee {
            from {
                transform: translateX(100%);
            }
            to {
                transform: translateX(-100%);
            }
        }
    </style>
</head>
<body>
    <div class="marquee-container">
        <div class="marquee-content">
            <?php echo htmlspecialchars($marquee_text); ?>
        </div>
    </div>
</body>
</html>


    <div class="container1">
        <div class="content-left">
            <h1>OUR PREMIUM SOFTWARE</h1>
            <!-- <p>Let's check our best services that will help in ranking, positioning, and managing your business from a small scale to a large scale.</p> -->
            <!-- <div class="button-container"><br>
                <a href="signup.html"><button class="start-now-btn">Start Now</button></a>
            </div>             -->
        </div>
        <div class="image-grid">
            <div class="image-item">
                <a href="https://greentickai.in/" target="_blank">
                    <img src="images/greentick-logo.jpg" alt="greentickai" />
                    <h3>GreenTickai</h3>
                </a>
            </div>
            <div class="image-item">
                <a href="https://deltateam.in/" target="_blank">
                    <img src="images/deltateam-logo.webp" alt="deltateam" />
                    <h3>DeltaTeam</h3>
                </a>
            </div>
            <div class="image-item">
                <a href="https://greatfamily.in/" target="_blank">
                    <img src="images/great-family-logo.png" alt="greatfamily" />
                    <h3>Great Family</h3>
                </a>
            </div>
            <div class="image-item">
                <a href="http://7wapi.com/" target="_blank">
                    <img src="images/wapi.png" alt="wapi" />
                    <h3>Wapi</h3>
                </a>
            </div>
            <div class="image-item">
                <a href="https://digiatme.com/" target="_blank">
                    <img src="images/virtual.png" alt="digiatme" />
                    <h3>Digiatme</h3>
                </a>
            </div>
            <div class="image-item">
                <a href="https://wesend.in/" target="_blank">
                    <img src="images/wesend-logo-removebg-preview.png" alt="wesend" />
                    <h3>Wesend</h3>
                </a>
            </div>
            <div class="image-item">
                <a href="https://idology.in/" target="_blank">
                    <img src="images/ideology.png" alt="idology" />
                    <h3>Idology</h3>
                </a>
            </div>  
            <div class="image-item">
                <a href="https://idology.in/" target="_blank">
                    <img src="images/offline.png" alt="idology" />
                    <h3>Services</h3>
                </a>
            </div>  
        </div>
    </div>




    <section id="features">
        <div class="features-container">
            <br>
            <h1>Our ERP Software</h1>
            <br>
            <div class="features-wrapper">
                <!-- Feature Box 1 -->
                <div class="feature-box">
                    <img aria-hidden="true" alt="Chat with your contacts" src="images/Images/Business.png" />
                    <a href="#business-erp"><h3>Business ERP</h3></a>
                    <p>
                        India's First GST Ready Business ERP Software for Supermarkets, Mobile Shops / Computers / Electronics / FMCG Dealers, Retailers / Wholesalers / Manufacturers etc.
                    </p>
                    <a href="https://oursoftware.in/Download/BusinessERP_Setup.exe" class="download-btn">Download</a>
                </div>
    
                <!-- Feature Box 2 -->
                <div class="feature-box">
                    <img aria-hidden="true" alt="Billing Software Configuration" src="images/Images/Jewelery.png" />
                    <a href="#jewellery-erp"><h3>Jewellery ERP</h3></a>
                    <p>
                        ERP Software for Jewelry Shops with Stock Management, Girvi management, Tag Printing, Today Rates, Ordering manage, Sale / Purchase, Financial Accounting & more.
                    </p>
                    <a href="https://oursoftware.in/Download/GoldERP_Setup.exe" class="download-btn">Download</a>
                </div>
    
                <!-- Feature Box 3 -->
                <div class="feature-box">
                    <img aria-hidden="true" alt="AI Chats" src="images/Images/Mandi.png" />
                    <a href="#mandi-erp"><h3>Mandi ERP (Unicode)</h3></a>
                    <p>
                        ERP Software for Sabzi Mandi Commission Agents with Supplier / Customer Bills, Rate / Weight Adjustment, Stock Management, Accounts, Crates, more.
                    </p>
                    <a href="https://oursoftware.in/Download/GoldERP_Setup.exe" class="download-btn">Download</a>
                </div>
    
                <!-- Feature Box 4 -->
                <div class="feature-box">
                    <img aria-hidden="true" alt="Customer Feedback" src="images/Images/Medical.png" />
                    <a href="#medical-erp"><h3>Medical ERP</h3></a>
                    <p>
                        ERP Software For Pharmaceutical Dealers and Distributors (Wholesale and Retail Chemists) with Stock management, Expiry Calculation & much more.
                    </p>
                    <a href="https://oursoftware.in/Download/MediCal_Setup.exe" class="download-btn">Download</a>
                </div>
    
                <!-- Feature Box 5 -->
                <div class="feature-box">
                    <img aria-hidden="true" alt="Data Analytics" src="images/Images/Hotel.png" />
                    <a href="#hotel-erp"><h3>Hotel ERP</h3></a>
                    <p>
                        Software for Hotels and Restaurants with K.O.T. Management, Table Booking, Room Rent Service, Billing, Stock Management, Production. Very Easy to operate.
                    </p>
                    <a href="https://oursoftware.in/Download/HotelERP_setup.exe" class="download-btn">Download</a>
                </div>
    
                <!-- Feature Box 6 -->
                <div class="feature-box">
                    <img aria-hidden="true" alt="Marketing Automation" src="images/Images/sheller.png" />
                    <a href="#sheller-erp"><h3>Sheller ERP</h3></a>
                    <p>
                        ERP Software For Rice Mills, Cotton Mill to fulfill requirements of Sheller Industries with Customer Bills, Rate / Weight Adjustment & much more.
                    </p>
                    <a href="https://oursoftware.in/Download/Sheller_setup.exe" class="download-btn">Download</a>
                </div>
    
                <!-- Feature Box 7 -->
                <div class="feature-box">
                    <img aria-hidden="true" alt="Marketing Automation" src="images/Images/Reatil.png" />
                    <a href="#retail-erp"><h3>Retail ERP</h3></a>
                    <p>
                        ERP Software for Apparels, Footwear, readymade garments retail showrooms to manage their stock Size / Color / Article wise. Barcode printer to print tags.
                    </p>
                    <a href="https://oursoftware.in/Download/RetailERP_Setup.exe" class="download-btn">Download</a>
                </div>
    
                <!-- Feature Box 8 -->
                <div class="feature-box">
                    <img aria-hidden="true" alt="Marketing Automation" src="images/Images/Shuttring.png" />
                    <a href="#shuttring-store"><h3>Shuttring Store</h3></a>
                    <p>
                        ERP Software for Shuttering / Scaffolding stores to make accurate rental bills, manage Stock, Control Leakage, integrated with Financial Accounting.
                    </p>
                    <a href="https://oursoftware.in/Download/Shuttring_Setup.exe" class="download-btn">Download</a>
                </div>
    
                <!-- Feature Box 9 -->
                <div class="feature-box">
                    <img aria-hidden="true" alt="Marketing Automation" src="images/Images/Lab.png" />
                    <a href="#lab-erp"><h3>Lab ERP</h3></a>
                    <p>
                        Software For Clinical Labs to maintain record of patients with accurate test reports. Completely customizable with own Tests and formulations.
                    </p>
                    <a href="https://oursoftware.in/Download/Lab_Setup.exe" class="download-btn">Download</a>
                </div>
    
                <!-- Feature Box 10 -->
                <div class="feature-box">
                    <img aria-hidden="true" alt="Marketing Automation" src="images/Images/Milk.png" />
                    <a href="#milk-man"><h3>Milk Man (Unicode)</h3></a>
                    <p>
                        Software for Milk Dairies maintain farmer record, FAT-SNF-CLR According, 10 Days Bill, Stock, Farmer Summary, Profit Loss, Farmer Bills.
                    </p>
                    <a href="https://oursoftware.in/Download/Milk%20Man_setup.exe" class="download-btn">Download</a>
                </div>
    
                <!-- Feature Box 11 -->
                <div class="feature-box">
                    <img aria-hidden="true" alt="Marketing Automation" src="images/Images/Institute.png" />
                    <a href="#institute-erp"><h3>Institute ERP</h3></a>
                    <p>
                        Software for Institutes to handle Enquiry, Admission, Fee Management, Library, Attendance, Time Table.
                    </p>
                    <a href="https://oursoftware.in/Download/InstitueERP_Setup.exe" class="download-btn">Download</a>
                </div>
    
                <!-- Feature Box 12 -->
                <div class="feature-box">
                    <img aria-hidden="true" alt="Marketing Automation" src="images/Images/Finance.png" />
                    <a href="#finance-erp"><h3>Finance ERP</h3></a>
                    <p>
                        Software for Non Banking Finance Companies to maintain customer and hypothecated Vehicle records & more.
                    </p>
                    <a href="https://oursoftware.in/Download/Finance_Setup.exe" class="download-btn">Download</a>
                </div>
    
                <!-- Feature Box 13 -->
                <div class="feature-box">
                    <img aria-hidden="true" alt="Marketing Automation" src="images/Images/Cold store.png" />
                    <a href="#cold-store"><h3>Cold Store</h3></a>
                    <p>
                        Cold Stores Management Software to track customer's stock Lot No. / Rack Wise. Record Material Inward / Outward challans, Stock Shifting From One Rack to another etc.
                    </p>
                    <a href="https://oursoftware.in/Download/cold_Setup.exe" class="download-btn">Download</a>
                </div>
    
                <!-- Feature Box 14 -->
                <div class="feature-box">
                    <img aria-hidden="true" alt="Marketing Automation" src="images/Images/School.png" />
                    <a href="#school-erp"><h3>School ERP</h3></a>
                    <p>
                        ERP Software for Schools & Colleges to handle Enquiry, Admission, Fee Management, Library, Attendance, Time Table, Certificates, ID Card, Reminder Letters, Demand Register.
                    </p>
                    <a href="https://oursoftware.in/Download/School_Setup.exe" class="download-btn">Download</a>
                </div>
    
                <!-- Feature Box 15 -->
                <div class="feature-box">
                    <img aria-hidden="true" alt="Marketing Automation" src="images/Images/Clinic.png" />
                    <a href="#clinic-erp"><h3>Clinic ERP</h3></a>
                    <p>
                        ERP Software For Hospitals with IPD, OPD, Billing, Accounting, Medicine Stock, Inventory Stock, Advance Payment & Balance Facility.
                    </p>
                    <a href="https://oursoftware.in/Download/Clinic_Setup.exe" class="download-btn">Download</a>
                </div>
    
                <!-- Feature Box 16 -->
                <div class="feature-box">
                    <img aria-hidden="true" alt="Marketing Automation" src="images/Images/Tailor.png" />
                    <a href="#tailor-master"><h3>Tailor Master</h3></a>
                    <p>
                        Tailor Master Software To maintain customer records, pending items, and payment. Customizable stitching orders and much more.
                    </p>
                    <a href="https://oursoftware.in/Download/TailorMaster_Setup.exe" class="download-btn">Download</a>
                </div>
    
                <!-- Feature Box 17 -->
                <div class="feature-box">
                    <img aria-hidden="true" alt="Marketing Automation" src="images/Images/Library.png" />
                    <a href="#library-erp"><h3>Library ERP</h3></a>
                    <p>
                        Software to manage Library Inventory, book issue / return with fine calculation, Search books by author, subject, title.
                    </p>
                    <a href="https://oursoftware.in/Download/Library_Setup.exe" class="download-btn">Download</a>
                </div>
    
            </div>
        </div>
    </section>



<!-- database and email starts here ============================== -->
<div class="container5">
    <h2>Database and Email</h2>
    <div class="main-box">
        <div class="small-box">
            <span class="box-title">Box 1</span>
        </div>
        <div class="small-box">
            <span class="box-title">Box 2</span>
        </div>
        <div class="small-box">
            <span class="box-title">Box 3</span>
        </div>
    </div>
</div>
<!-- database and email ends here ============================== -->



    <!-- chat sliding section ========================= -->
    <div id="demo" class="chat-section-container">
        <div class="slider">
            <div class="chat-section">
                <div class="chat-content">
                    <h1>Test the AI chat system - Slide 1!</h1>
                    <p>This is the first slide. Start exploring the demo!</p>
                    <button>Start demo</button>
                </div>
                <div class="chat-image">
                    <img src="images/qr.png" alt="Chat Image">
                </div>
            </div>
            <div class="chat-section">
                <div class="chat-content">
                    <h1>Test the AI chat system - Slide 2!</h1>
                    <p>This is the second slide. Keep going!</p>
                    <button>Next step</button>
                </div>
                <div class="chat-image">
                    <img src="images/qr.png" alt="Chat Image">
                </div>
            </div>
            <div class="chat-section">
                <div class="chat-content">
                    <h1>Test the AI chat system - Slide 3!</h1>
                    <p>This is the final slide in the series. Enjoy the demo!</p>
                    <button>Complete demo</button>
                </div>
                <div class="chat-image">
                    <img src="images/qr.png" alt="Chat Image">
                </div>
            </div>
        </div>
        <button class="prev" onclick="prevSlide()">&#10094;</button>
        <button class="next" onclick="nextSlide()">&#10095;</button>
    </div>
<!-- chat sliding section end ================== -->

    



</body>
</html>

<!-- contact page ends here =========================== -->
    

<script src="script.js"></script>
<!-- faq code ends here ============================================ -->
    <!-- sliding section js =============== -->
 <script>
            let currentSlide = 0;
        const slides = document.querySelectorAll('.chat-section');
        const totalSlides = slides.length;
        let slideInterval;

        function showSlide(index) {
            const slider = document.querySelector('.slider');
            if (index >= totalSlides) {
                currentSlide = 0;
            } else if (index < 0) {
                currentSlide = totalSlides - 1;
            } else {
                currentSlide = index;
            }
            slider.style.transform = `translateX(-${currentSlide * 100}%)`;
        }

        function nextSlide() {
            showSlide(currentSlide + 1);
        }

        function prevSlide() {
            showSlide(currentSlide - 1);
        }

        function startAutoSlide() {
            slideInterval = setInterval(nextSlide, 3000); // Change slide every 5 seconds
        }

        function stopAutoSlide() {
            clearInterval(slideInterval);
        }

        // Initial setup
        showSlide(currentSlide);
        startAutoSlide();

        // Optional: Stop auto sliding when user interacts with navigation buttons
        document.querySelector('.prev').addEventListener('click', function() {
            prevSlide();
            stopAutoSlide();
            startAutoSlide(); // Restart auto sliding
        });

        document.querySelector('.next').addEventListener('click', function() {
            nextSlide();
            stopAutoSlide();
            startAutoSlide(); // Restart auto sliding
        });
 </script>
 <!-- sliding js ends here =============================== -->

    <script>
        function logout() {
            // Clear the login flag
            localStorage.removeItem('isLoggedIn');
            // Redirect to the login page
            window.location.href = 'login.html';
        }
    </script>
    <script>
        const faqItems = document.querySelectorAll('.faq-item');

        faqItems.forEach(item => {
            const question = item.querySelector('.question');
            const answer = item.querySelector('.answer');
            const toggleIcon = item.querySelector('.toggle-icon');

        question.addEventListener('click', () => {
            answer.classList.toggle('active');
            toggleIcon.textContent = answer.classList.contains('active') ? '-' : '+';
        });
});

    </script>
    
</body>
</html>