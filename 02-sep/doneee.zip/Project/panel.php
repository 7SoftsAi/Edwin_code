<?php
session_start();

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

echo "Welcome to your dashboard, " . $_SESSION['first_name'] . "!";
?>

<a href="logout.php">Logout</a>
