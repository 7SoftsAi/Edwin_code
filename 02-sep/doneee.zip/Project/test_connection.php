<?php
$host = 'localhost';     // Your database host
$username = 'root';      // Your database username (default is 'root' for XAMPP)
$password = '';          // Your database password (default is empty for XAMPP)
$database = 'user_auth';  // Replace with your actual database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
echo "Connected successfully";
?>
