<?php
// Database connection settings
$host = 'localhost';     // Your database host
$username = 'root';      // Your database username (default is 'root' for XAMPP)
$password = '';          // Your database password (default is empty for XAMPP)
$database = 'user_auth';  // Replace with your actual database name

// Create a new MySQLi connection
$mysqli = new mysqli($host, $username, $password, $database);

// Check for connection errors
if ($mysqli->connect_error) {
    die('Database connection failed: ' . $mysqli->connect_error);
}
?>
